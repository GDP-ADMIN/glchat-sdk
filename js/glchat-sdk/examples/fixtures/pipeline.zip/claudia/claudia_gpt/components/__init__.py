"""Claudia GPT pipeline components.

Authors:
    Samuel Lusandi (samuel.lusandi@gdplabs.id)
"""
