"""Response Synthesizer for Claudia Pipeline.

Authors:
    Samuel Lusandi (samuel.lusandi@gdplabs.id)
"""

from typing import Any

from gllm_core.event import EventEmitter
from gllm_core.constants import EventLevel, EventType
from gllm_inference.schema import Attachment, MultimodalContent, PromptRole
from gllm_generation.response_synthesizer.response_synthesizer import BaseResponseSynthesizer

class ClaudiaResponseSynthesizer(BaseResponseSynthesizer):

    def __init__(self, model: str, key: str, api_key: str):
        super().__init__()
        self.model = model
        self.key = key
        self.api_key = api_key

    async def synthesize_response(
        self,
        query: str | None = None,
        state_variables: dict[str, Any] | None = None,
        history: list[tuple[PromptRole, str | list[Any]]] | None = None,
        extra_contents: list[MultimodalContent] | None = None,
        attachments: list[Attachment] | None = None,
        hyperparameters: dict[str, Any] | None = None,
        event_emitter: EventEmitter | None = None,
        system_multimodal_contents: list[Any] | None = None,
        user_multimodal_contents: list[Any] | None = None,
    ) -> str:
        """Synthesizes a response based on the provided query.

        This abstract method must be implemented by subclasses to define the logic for generating a response. It
        may optionally take an input `query`, some other input variables passed through `state_variables`, and an
        `event_emitter`. It returns the synthesized response as a string.

        Args:
            query (str | None, optional): The input query used to synthesize the response. Defaults to None.
            state_variables (dict[str, Any] | None, optional): Additional state variables to assist in generating the
                response. Defaults to None.
            history (list[tuple[PromptRole, str | list[Any]]] | None, optional): The chat history of the conversation
                to be considered in generating the response. Defaults to None.
            extra_contents (list[MultimodalContent] | None, optional): The additional multimodal contents to be considered
                in generating the response. Defaults to None.
            attachments (list[Attachment] | None, optional): The attachments to be considered in generating the response.
                Defaults to None.
            hyperparameters (dict[str, Any] | None, optional): The hyperparameters to be considered in generating the response.
                Defaults to None.
            event_emitter (EventEmitter | None, optional): The event emitter for handling events during response
                synthesis. Defaults to None.
            system_multimodal_contents (list[Any] | None, optional): The system multimodal contents to be considered
                in generating the response. Defaults to None.
            user_multimodal_contents (list[Any] | None, optional): The user multimodal contents to be considered in
                generating the response. Defaults to None.

        Returns:
            str: The synthesized response.

        Raises:
            NotImplementedError: If the method is not implemented in a subclass.
        """
        final_response = "echo: " + query

        if event_emitter and final_response:
            await event_emitter.emit(
                final_response, 
                event_level=EventLevel.INFO, 
                event_type=EventType.RESPONSE
            )
        
        return final_response
