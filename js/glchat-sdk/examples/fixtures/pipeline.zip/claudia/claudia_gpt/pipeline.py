"""Simple Pipeline Configuration.

Authors:
    Samuel Lusandi (samuel.lusandi@gdplabs.id)
"""

import os
from dotenv import load_dotenv
from typing import Any

from gllm_datastore.sql_data_store import SQLAlchemySQLDataStore
from gllm_pipeline.pipeline.pipeline import Pipeline
from gllm_pipeline.steps import step
from gllm_plugin.pipeline.pipeline_plugin import PipelineBuilderPlugin

from claudia_gpt.components.chat_history_manager import ClaudiaChatHistoryManager
from claudia_gpt.components.response_synthesizer import ClaudiaResponseSynthesizer
from claudia_gpt.preset_config import ClaudiaPresetConfig
from claudia_gpt.state import ClaudiaState, ClaudiaStateKeys


load_dotenv(override=True)


class ClaudiaPipelineBuilderPlugin(PipelineBuilderPlugin[ClaudiaState, ClaudiaPresetConfig]):
    """Claudia Pipeline Builder Plugin.

    Inherits attributes from `PipelineBuilderPlugin`.
    """

    name = "claudia-gpt"
    preset_config_class = ClaudiaPresetConfig

    def __init__(self):
        """Initialize the Claudia pipeline builder."""
        super().__init__()
        self.data_store = SQLAlchemySQLDataStore(engine_or_url=os.getenv("GLCHAT_DB_URL"))

    async def build(self, pipeline_config: dict[str, Any]) -> Pipeline:
        """Build the pipeline.

        Args:
            pipeline_config (dict[str, Any]): The pipeline configuration.

        Returns:
            Pipeline: The simple pipeline.
        """
        model = str(pipeline_config["model_name"]) if "model_name" in pipeline_config else os.getenv("LANGUAGE_MODEL", "openai/gpt-4.1")
        key = os.getenv(pipeline_config["api_key"]) if "api_key" in pipeline_config else os.getenv("LLM_API_KEY", "")
        
        api_key_key = pipeline_config.get("api_key")
        api_key = os.getenv(api_key_key, "")

        response_synthesizer_step = step(
            component=ClaudiaResponseSynthesizer(model=model, key=key, api_key=api_key),
            input_state_map={
                ClaudiaStateKeys.QUERY: ClaudiaStateKeys.QUERY,
                ClaudiaStateKeys.EVENT_EMITTER: ClaudiaStateKeys.EVENT_EMITTER,
            },
            output_state=ClaudiaStateKeys.RESPONSE,
        )

        save_message_step = step(
            component=ClaudiaChatHistoryManager(data_store=self.data_store),
            input_state_map={
                ClaudiaStateKeys.QUERY: ClaudiaStateKeys.QUERY,
                ClaudiaStateKeys.RESPONSE: ClaudiaStateKeys.RESPONSE,
                ClaudiaStateKeys.EVENT_EMITTER: ClaudiaStateKeys.EVENT_EMITTER,
            },
            output_state=ClaudiaStateKeys.HISTORY,
            runtime_config_map = {
                "user_id": "user_id",
                "conversation_id": "conversation_id",
                "parent_id": "parent_id",
                "user_message_id": "user_message_id",
                "assistant_message_id": "assistant_message_id",
                "source": "source",
                "quote": "quote",
                "attachments": "attachments",
                "original_message": "original_message",
            },
            fixed_args={"operation": "write"},
        )

        return Pipeline(
            steps=[response_synthesizer_step, save_message_step],
            state_type=ClaudiaState
        )

    def build_initial_state(
        self, request: dict[str, Any], pipeline_config: dict[str, Any], **kwargs: Any
    ) -> ClaudiaState:
        """Build the initial state for pipeline invoke.

        Args:
            request (dict[str, Any]): The given request from the user.
            pipeline_config (dict[str, Any]): The pipeline configuration.
            **kwargs (Any): A dictionary of arguments required for building the initial state.

        Returns:
            ClaudiaState: The initial state.
        """
        return ClaudiaState(
            query=request.get("message"),
            response=None,
            history=None,
            event_emitter=kwargs.get("event_emitter")
        )
